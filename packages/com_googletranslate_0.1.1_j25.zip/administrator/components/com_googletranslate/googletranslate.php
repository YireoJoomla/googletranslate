<?php
/**
 * Joomla! component GoogleTranslate
 *
 * @author Yireo
 * @package GoogleTranslate
 * @copyright Copyright 2011
 * @license GNU Public License
 * @link http://www.yireo.com/
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Require the base controller
require_once (JPATH_COMPONENT.DS.'controller.php');
$controller	= new GoogleTranslateController( );

// Perform the Request task
$controller->execute(JRequest::getCmd('task'));
$controller->redirect();

