<?php
/*
 * Joomla! Editor Button Plugin - Google Translate
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * Google Translate Editor Button Plugin
 */
class plgButtonGoogleTranslate extends JPlugin
{
    /**
     * Method to display the button
     *
     * @param string $name
     */
    public function onDisplay( $name )
    {
        // Add the proper JavaScript to this document
        $document = JFactory::getDocument();
        $document->addScript(JURI::base().'../media/com_googletranslate/js/jquery.js');
        $document->addScript(JURI::base().'../media/com_googletranslate/js/editor-xtd.js');
		$document->addScriptDeclaration("jQuery.noConflict();\n");
        $document->addStyleSheet(JURI::base().'../media/com_googletranslate/css/editor-xtd.css');

        // Detect the language
        $lang = null;

        // Construct the button
		$button = new JObject();
		$button->set('modal', false);
		$button->set('onclick', 'javascript:doGoogleTranslate(\''.$name.'\', \''.$lang.'\', this);return false;');
		$button->set('text', 'Google Translate');
		$button->set('name', 'googletranslate');
		$button->set('link', '#');

		return $button;
    }
}
